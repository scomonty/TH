import React from 'react';

const Footer = () => <span>2017</span>;

export default Footer;

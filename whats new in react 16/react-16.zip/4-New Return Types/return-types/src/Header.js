import React from 'react';

const Header = () => <p>Hello from the Header!</p>;

export default Header;

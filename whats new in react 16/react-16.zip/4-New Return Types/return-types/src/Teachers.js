import React from 'react';

const Teachers = () =>
  <div className="teachers">
    <h1>Teacher List</h1>
    <ul>
      <li>Alena</li>
      <li>Nick</li>
      <li>Ben</li>
      <li>Jay</li>
    </ul>
  </div>;

export default Teachers;

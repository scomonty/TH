const Header = () => 'Hello from the Header!';

export default Header;

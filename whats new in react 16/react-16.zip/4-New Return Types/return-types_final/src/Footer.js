const Footer = () => 2017;

export default Footer;

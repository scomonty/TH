import React from 'react';

const JSTeachers = () => [
  <li key="1">Treasure</li>,
  <li key="2">Guil</li>,
  <li key="3">James</li>
];

export default JSTeachers;

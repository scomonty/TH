import React from 'react';
import { render } from 'react-dom';
import Scoreboard from './Scoreboard';

render(
  <Scoreboard />,
  document.getElementById('root')
);
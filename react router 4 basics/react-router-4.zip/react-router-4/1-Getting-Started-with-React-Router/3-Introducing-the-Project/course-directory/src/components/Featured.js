import React from 'react';

const Featured = () => {

  return (
    <div className="main-content">
      <h2>Featured: </h2>
      <p>Introducing <strong></strong>, a teacher who loves teaching courses about <strong></strong>!</p>
    </div>
  );
}

export default Featured;